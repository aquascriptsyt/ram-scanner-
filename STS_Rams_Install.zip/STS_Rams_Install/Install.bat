@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================================
echo  STS Rams - One-Click Install
echo ============================================================
echo This will:
echo   1. Move the STS Rams apps into a folder called
echo      "STS Scanner Apps" next to this installer
echo   2. Install Python (if needed - just for your Windows user
echo      account, no admin rights needed)
echo   3. Install the required Python packages
echo   4. Check for the Microsoft Edge WebView2 Runtime
echo ============================================================
echo.
pause

REM ------------------------------------------------------------------
REM 1. Move the payload apps and their code into place
REM ------------------------------------------------------------------
echo.
echo [1/5] Setting up "STS Scanner Apps" and "STS Scanner Data" folders...

set DEST=%~dp0STS Scanner Apps
set DATADEST=%~dp0STS Scanner Data

if exist "%DEST%" (
    echo "STS Scanner Apps" already exists - leaving existing files as
    echo they are and only adding anything missing.
) else (
    mkdir "%DEST%"
)

if not exist "%DATADEST%" (
    mkdir "%DATADEST%"
)

if exist "%~dp0_payload\STS_Rams" (
    if not exist "%DEST%\STS_Rams" (
        echo Moving STS Rams launcher into place...
        move "%~dp0_payload\STS_Rams" "%DEST%\STS_Rams" >nul
    )
)

if exist "%~dp0_payload\data_src\rams" (
    if not exist "%DATADEST%\src_rams" (
        echo Moving STS Rams program files into "STS Scanner Data"...
        move "%~dp0_payload\data_src\rams" "%DATADEST%\src_rams" >nul
    )
)

rmdir "%~dp0_payload\data_src" >nul 2>nul
rmdir "%~dp0_payload" >nul 2>nul

echo Done. Apps are now in: %DEST%

REM ------------------------------------------------------------------
REM 2. Find or install Python
REM ------------------------------------------------------------------
REM Rather than relying on "where python" (which depends on PATH being
REM refreshed - unreliable in the same window right after installing),
REM this searches the actual known install locations directly and sets
REM PYEXE to the real python.exe path. Everything below uses %PYEXE%
REM instead of the bare "python" command, so it works in this SAME run
REM even if Windows hasn't refreshed this window's PATH yet.
REM ------------------------------------------------------------------
echo.
echo [2/5] Checking for Python...

set "PYEXE="

REM Try every python.exe on PATH, but SKIP the fake Microsoft Store
REM stub that Windows puts at ...\WindowsApps\python.exe by default -
REM that file exists even when real Python isn't installed, and
REM running it just prints a Store prompt and does nothing.
where python >nul 2>nul
if %errorlevel% == 0 (
    for /f "delims=" %%P in ('where python') do (
        echo %%P | findstr /i "WindowsApps" >nul
        if errorlevel 1 (
            if not defined PYEXE set "PYEXE=%%P"
        )
    )
)

REM Also check the standard per-user install location directly, in
REM case PATH isn't refreshed yet from an earlier install
if not defined PYEXE (
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
        if exist "%%D\python.exe" set "PYEXE=%%D\python.exe"
    )
)

REM Final sanity check - actually run it and confirm it reports a
REM version, rather than trusting the file merely exists
if defined PYEXE (
    "%PYEXE%" --version >nul 2>nul
    if errorlevel 1 set "PYEXE="
)

if defined PYEXE (
    echo Found Python at: !PYEXE!
    "!PYEXE!" --version
) else (
    echo Python not found. Downloading installer...
    set PYTHON_INSTALLER=%TEMP%\python-installer.exe
    del "!PYTHON_INSTALLER!" >nul 2>nul

    REM Try a short list of known-good versions in order, since a
    REM single hardcoded version can go stale (older 3.12.x releases
    REM eventually stop shipping Windows binary installers entirely
    REM and only offer source - hence "404 Not Found" if that happens).
    REM The first one that actually downloads successfully is used.
    set "DOWNLOAD_OK=0"
    for %%V in (3.13.15 3.12.10 3.13.5 3.12.7) do (
        if "!DOWNLOAD_OK!"=="0" (
            echo Trying Python %%V...
            set "PYTHON_URL=https://www.python.org/ftp/python/%%V/python-%%V-amd64.exe"
            powershell -Command "try { Invoke-WebRequest -Uri '!PYTHON_URL!' -OutFile '!PYTHON_INSTALLER!' -ErrorAction Stop } catch { exit 1 }" >nul 2>nul
            if exist "!PYTHON_INSTALLER!" (
                for %%F in ("!PYTHON_INSTALLER!") do if %%~zF GTR 1000000 set "DOWNLOAD_OK=1"
            )
            if "!DOWNLOAD_OK!"=="0" del "!PYTHON_INSTALLER!" >nul 2>nul
        )
    )

    if "!DOWNLOAD_OK!"=="0" (
        echo ERROR: Could not download a Python installer from python.org.
        echo Check your internet connection and try again, or install
        echo Python manually from python.org ^(tick "Add python.exe to PATH"
        echo during setup^), then run Install.bat again.
        pause
        exit /b 1
    )

    echo Installing Python for your user account only - no admin rights needed for this step.
    echo This can take a minute - please wait...
    start /wait "" "!PYTHON_INSTALLER!" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0

    del "!PYTHON_INSTALLER!" >nul 2>nul

    REM Directly locate the freshly-installed python.exe rather than
    REM trusting PATH to already be refreshed in this window
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
        if exist "%%D\python.exe" set "PYEXE=%%D\python.exe"
    )

    REM Give the installer a few extra seconds and retry once if the
    REM folder wasn't there yet (slow disks / antivirus scanning)
    if not defined PYEXE (
        echo Waiting a moment for installation to finish writing files...
        timeout /t 8 /nobreak >nul
        for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
            if exist "%%D\python.exe" set "PYEXE=%%D\python.exe"
        )
    )

    if not defined PYEXE (
        echo.
        echo ERROR: Python installer ran but python.exe could not be found
        echo afterward. This is unusual - please try running Install.bat
        echo again, or install Python manually from python.org and tick
        echo "Add Python to PATH" during setup, then run Install.bat again.
        pause
        exit /b 1
    )

    echo Python installed successfully at: !PYEXE!
    call :RefreshPath
)

REM ------------------------------------------------------------------
REM 3. Install required Python packages
REM ------------------------------------------------------------------
echo.
echo [3/5] Installing required Python packages...
echo This includes the app framework, Excel support, and the window
echo display library. This may take a few minutes on first run.
"%PYEXE%" -m pip install --upgrade pip --quiet --user >nul 2>nul

"%PYEXE%" -m pip install flask openpyxl pywebview pywin32 pythonnet comtypes --quiet 2>"%TEMP%\pip_error.txt"
if not %errorlevel% == 0 (
    echo First attempt failed - retrying with --user (installs just for
    echo your account, no extra permissions needed)...
    "%PYEXE%" -m pip install --user flask openpyxl pywebview pywin32 pythonnet comtypes --quiet
    if not %errorlevel% == 0 (
        echo.
        echo ERROR: Could not install the required Python packages even
        echo with --user. Details from the first attempt:
        type "%TEMP%\pip_error.txt"
        echo.
        echo This usually means either there is no internet connection,
        echo or antivirus/company software is blocking pip. Please show
        echo this message to whoever set up STS Rams for you.
        del "%TEMP%\pip_error.txt" >nul 2>nul
        pause
        exit /b 1
    )
    echo Packages installed successfully using --user mode.
) else (
    echo Packages installed.
)
del "%TEMP%\pip_error.txt" >nul 2>nul

REM ------------------------------------------------------------------
REM 4. pywin32 post-install step (required on Windows for pythonnet/COM)
REM ------------------------------------------------------------------
echo.
echo [4/5] Finishing Windows integration setup...
"%PYEXE%" -m pywin32_postinstall -install >nul 2>nul
echo Done.

REM ------------------------------------------------------------------
REM 5. Check for WebView2 Runtime (needed to actually display the app)
REM ------------------------------------------------------------------
echo.
echo [5/5] Checking for Microsoft Edge WebView2 Runtime...
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" >nul 2>nul
if %errorlevel% == 0 (
    echo WebView2 Runtime is already installed.
    goto :webview_done
)
reg query "HKLM\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" >nul 2>nul
if %errorlevel% == 0 (
    echo WebView2 Runtime is already installed.
    goto :webview_done
)

echo WebView2 Runtime not detected. Downloading the installer...
echo ^(This is a small, official Microsoft download - required for the
echo app window to display properly^)
set WEBVIEW2_URL=https://go.microsoft.com/fwlink/p/?LinkId=2124703
set WEBVIEW2_INSTALLER=%TEMP%\MicrosoftEdgeWebview2Setup.exe

powershell -Command "Invoke-WebRequest -Uri '%WEBVIEW2_URL%' -OutFile '%WEBVIEW2_INSTALLER%'"
if exist "%WEBVIEW2_INSTALLER%" (
    echo Installing WebView2 Runtime - a Windows permission prompt may
    echo appear for this step specifically; click Yes.
    start /wait "" "%WEBVIEW2_INSTALLER%" /silent /install
    del "%WEBVIEW2_INSTALLER%" >nul 2>nul
    echo WebView2 Runtime installed.
) else (
    echo Could not download WebView2 Runtime automatically. The app may
    echo still work if it's already present on this PC ^(most Windows 10/11
    echo machines have it by default^). If the app window fails to open,
    echo download and install it manually from:
    echo https://developer.microsoft.com/microsoft-edge/webview2/
)

:webview_done
echo.
echo ============================================================
echo  Install complete!
echo ============================================================
echo Two folders were set up next to this installer:
echo   "STS Scanner Apps"     just the launcher - double-click here to run
echo   "STS Scanner Data"     program files and settings
echo   "STS Scanner Sheets"   every Excel sheet you log (created automatically)
echo.
echo To run STS Rams, open "STS Scanner Apps\STS_Rams" and double-click:
echo   "Start STS Rams.bat"
echo.
echo Sheet-delete password: DEL-Z3XA563PZE4RAZY
echo ============================================================
pause
exit /b 0

:RefreshPath
for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "SYS_PATH=%%B"
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USER_PATH=%%B"
set "PATH=%SYS_PATH%;%USER_PATH%"
exit /b 0
