"""
STS Rams - Settings
---------------------
Persists bypass toggles to disk (settings.json next to this script) so
they survive app restarts.

When a bypass is ON for a field, a missing value for that field after
auto-detect does NOT trigger the warning prompt - the entry just logs
with that field blank. The master switch overrides all individual
toggles when on.
"""

import os
import json
import threading

import paths

SETTINGS_PATH = os.path.join(paths.DATA_FOLDER, "settings.json")

_lock = threading.Lock()

DEFAULT_SETTINGS = {
    "master_bypass": False,
    "bypass_part_number": False,
    "bypass_ram_type": False,
    "bypass_manufacturer": False,
    "bypass_speed": False,
    "bypass_form_factor": False,
    "bypass_capacity": False,
}

_settings = dict(DEFAULT_SETTINGS)


def _load():
    global _settings
    if os.path.exists(SETTINGS_PATH):
        try:
            with open(SETTINGS_PATH, "r") as f:
                loaded = json.load(f)
            _settings = {**DEFAULT_SETTINGS, **loaded}
            return
        except (json.JSONDecodeError, IOError):
            pass
    _settings = dict(DEFAULT_SETTINGS)


def _save():
    with open(SETTINGS_PATH, "w") as f:
        json.dump(_settings, f, indent=2)


_load()


def get_settings() -> dict:
    with _lock:
        return dict(_settings)


def update_settings(new_values: dict) -> dict:
    with _lock:
        for key in DEFAULT_SETTINGS:
            if key in new_values:
                _settings[key] = bool(new_values[key])
        _save()
        return dict(_settings)


# Maps the bypass setting key to the entry field it governs
FIELD_BYPASS_MAP = {
    "Part Number": "bypass_part_number",
    "RAM Type": "bypass_ram_type",
    "Manufacturer": "bypass_manufacturer",
    "Speed": "bypass_speed",
    "Form Factor": "bypass_form_factor",
    "Capacity": "bypass_capacity",
}


def is_field_bypassed(field_name: str) -> bool:
    """True if this field should skip the warning prompt when missing."""
    with _lock:
        if _settings.get("master_bypass"):
            return True
        key = FIELD_BYPASS_MAP.get(field_name)
        return bool(key and _settings.get(key))


def filter_missing_fields(missing_fields: list) -> list:
    """Given a list of missing field names, returns only the ones that
    are NOT bypassed - i.e. the ones that should still trigger a warning."""
    return [f for f in missing_fields if not is_field_bypassed(f)]
