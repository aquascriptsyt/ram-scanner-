"""
STS Rams - shared path resolution
------------------------------------
Two ways this runs:

1. Normal (via "Start STS Rams.bat"): this file lives in
   "STS Scanner Data/src_rams" alongside server.py, templates, etc.

2. Built as STS Rams.exe (via "Build App.bat"): the exe sits in
   "STS Scanner Apps/STS_Rams/STS Rams.exe" - one folder level
   shallower than case 1, so the sibling-folder math differs.

Layout either way:

    <install root>/
        STS Scanner Apps/
            STS_Rams/
                STS Rams.exe      <- built exe lives here (if built)
        STS Scanner Data/
            src_rams/              <- this file, server.py, etc. (source mode)
            shared_auth_data.json, settings.json, etc.
        STS Scanner Sheets/        <- all Excel output

If the sibling folders don't exist yet (first run), they're created
automatically - nothing needs to be set up by hand.
"""

import os
import sys

if getattr(sys, "frozen", False):
    # Running as the built .exe - sys.executable is the REAL exe path
    # (unlike __file__, which points into a temp extraction folder and
    # would give the wrong answer here). The exe sits in
    # "STS Scanner Apps/STS_Rams/", one level shallower than the
    # source-mode case below.
    EXE_FOLDER = os.path.dirname(os.path.abspath(sys.executable))   # .../STS Scanner Apps/STS_Rams
    APPS_ROOT = os.path.dirname(EXE_FOLDER)                          # .../STS Scanner Apps
    INSTALL_ROOT = os.path.dirname(APPS_ROOT)                        # the common parent
else:
    CODE_FOLDER = os.path.dirname(os.path.abspath(__file__))   # .../STS Scanner Data/src_rams
    DATA_FOLDER_DIRECT = os.path.dirname(CODE_FOLDER)           # .../STS Scanner Data
    INSTALL_ROOT = os.path.dirname(DATA_FOLDER_DIRECT)          # the common parent

DATA_FOLDER = os.path.join(INSTALL_ROOT, "STS Scanner Data")
SHEETS_FOLDER = os.path.join(INSTALL_ROOT, "STS Scanner Sheets")

os.makedirs(DATA_FOLDER, exist_ok=True)
os.makedirs(SHEETS_FOLDER, exist_ok=True)

