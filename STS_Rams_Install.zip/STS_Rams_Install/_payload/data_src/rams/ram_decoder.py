"""
STS Rams - RAM part-number decoder
------------------------------------
Auto-detects the manufacturer from a scanned barcode / part number and
decodes as much as possible: manufacturer, RAM generation (DDR-DDR5),
form factor, capacity, speed.

Covers every manufacturer with a genuinely documented, publicly
available part-number scheme: Samsung, SK Hynix, Micron, Nanya,
Kingston (all lines, DDR-DDR5), Crucial, Corsair (DDR1-DDR5), Apacer
(via printed-label text, since its barcode is an internal SKU with no
public decode table).

decode_auto(raw_value, label_text=None) is the main entry point - it
tries every known brand's pattern against the string and returns the
first confident match, or an "Unknown" result with every field left
blank so the caller can prompt the user to fill them in.
"""

import re


# ============================================================================
# Samsung
# ============================================================================
SAMSUNG_MODULE_TYPE = {
    "M378": ("DDR3", "UDIMM (Desktop, Unbuffered)"),
    "M391": ("DDR3", "UDIMM ECC (Desktop, Unbuffered ECC)"),
    "M393": ("DDR3", "RDIMM (Server, Registered)"),
    "M471": ("DDR3", "SODIMM (Laptop)"),
    "M368": ("DDR2", "UDIMM (Desktop, Unbuffered)"),
    "M370": ("DDR2", "SODIMM (Laptop)"),
    "M470": ("DDR2", "SODIMM (Laptop)"),
    "M378A": ("DDR4", "UDIMM (Desktop, Unbuffered)"),
    "M471A": ("DDR4", "SODIMM (Laptop)"),
    "M393A": ("DDR4", "RDIMM (Server, Registered)"),
    "M321R": ("DDR5", "UDIMM (Desktop, Unbuffered)"),
    "M425R": ("DDR5", "SODIMM (Laptop)"),
    "M323R": ("DDR5", "RDIMM (Server, Registered)"),
}

SAMSUNG_DENSITY = {
    "3223": "256MB", "6523": "512MB", "5673": "2GB", "5773": "2GB",
    "5273": "4GB", "5173": "4GB", "2873": "4GB", "1G73": "8GB",
    "2G73": "16GB", "2G70": "16GB", "5270": "4GB", "2874": "4GB",
    # Real Samsung DDR2 SODIMM density codes (M470T prefix), verified
    # against Samsung's own official product selection guide:
    "6554": "512MB", "2953": "1GB", "2864": "1GB", "5663": "2GB",
}

SAMSUNG_SPEED = {
    "CCC": "PC2700 (DDR-333, old)", "CH9": "PC3-10600 (DDR3-1333)",
    "CF8": "PC3-8500 (DDR3-1066)", "CD9": "PC3-10600 (DDR3-1333)",
    "CJ8": "PC3-12800 (DDR3-1600)", "CK0": "PC3-12800 (DDR3-1600)",
    "CMA": "PC3-14900 (DDR3-1866)", "YH9": "PC3L-10600 (DDR3L-1333, low voltage)",
    "YK0": "PC3L-12800 (DDR3L-1600, low voltage)",
    # Real Samsung DDR2 SODIMM speed suffix codes, verified against
    # Samsung's official product guide and matching retailer listings:
    "CE6": "PC2-5300 (DDR2-667)", "CD5": "PC2-4200 (DDR2-533)",
    "E6": "PC2-5300 (DDR2-667)", "D5": "PC2-4200 (DDR2-533)",
}


def _strip_country_and_suffix(raw):
    """Strips a leading country code (CN/KR/PH...) and trailing date-code
    suffix (with or without an 'S' separator) from Samsung labels."""
    val = raw.strip().upper()
    country_match = re.match(r"^([A-Z]{2,3})\s+(M.*)", val)
    if country_match:
        val = country_match.group(2)
    s_match = re.match(r"^(M[A-Z0-9\-]+?)\s+S\s+\d{3,4}$", val)
    if s_match:
        return s_match.group(1)
    no_s_match = re.match(r"^(M[A-Z0-9\-]+?)\s+\d{3,4}$", val)
    if no_s_match:
        return no_s_match.group(1)
    bare_match = re.match(r"^(M[A-Z0-9\-]+)$", val)
    if bare_match:
        return bare_match.group(1)
    return val


def decode_samsung(raw_value: str):
    clean_pn = _strip_country_and_suffix(raw_value)
    pn = clean_pn.upper()
    result = {"manufacturer": "Samsung", "ram_type": None, "form_factor": None,
              "capacity": None, "speed": None}

    prefix_match = re.match(r"^(M\d{3}A?|M321R|M425R|M323R)", pn)
    if prefix_match:
        prefix = prefix_match.group(1)
        if prefix in SAMSUNG_MODULE_TYPE:
            ram_type, form_factor = SAMSUNG_MODULE_TYPE[prefix]
            result["ram_type"] = ram_type
            result["form_factor"] = form_factor

    remainder = pn[len(prefix_match.group(1)):] if prefix_match else pn
    density_match = re.match(r"^[A-Z](\d[A-Z0-9]{3})", remainder)
    if density_match and density_match.group(1) in SAMSUNG_DENSITY:
        result["capacity"] = SAMSUNG_DENSITY[density_match.group(1)]

    if "-" in pn:
        speed_code = pn.split("-")[-1]
        if speed_code in SAMSUNG_SPEED:
            result["speed"] = SAMSUNG_SPEED[speed_code]

    result["part_number"] = clean_pn
    result["raw_value"] = raw_value.strip()
    return result


def looks_like_samsung(raw: str) -> bool:
    val = raw.strip().upper()
    return bool(re.match(r"^([A-Z]{2,3}\s+)?M(\d{3}|321R|425R|323R)", val))


# ============================================================================
# Hynix / SK Hynix
# ============================================================================
HYNIX_DENSITY_HMT = {
    "112": "1GB", "125": "2GB", "151": "4GB", "325": "2GB", "351": "4GB",
    "451": "4GB", "425": "8GB", "42G": "16GB", "32G": "16GB", "84G": "32GB",
    "31G": "8GB",
}
HYNIX_SPEED_SUFFIX = {
    "H9": "PC3-10600 (DDR3-1333)", "PB": "PC3-8500 (DDR3-1066)",
    "PN": "PC3-8500 (DDR3-1066)", "RD": "PC3-12800 (DDR3-1600)",
    "G7": "PC3-8500R (DDR3-1066, Registered)", "D43": "PC2-4200 (DDR2-533)",
    "D3": "PC2-3200 (DDR2-400)",
    "Y5": "PC2-5300/PC2-6400 (DDR2-667/800)", "C4": "PC2-4200 (DDR2-533)",
    "C6": "PC2-6400 (DDR2-800)", "C5": "PC2-5300 (DDR2-667)",
}


# Density codes for Hynix's older HYMD/HYMP DDR2 naming (the 3 digits
# right after the prefix) - verified against real retailer listings for
# HYMD232... (256MB), HYMD264.../HYMD564... (512MB), HYMD512.../HYMP112...
# (1GB), and HYMP125... (2GB). Some codes overlap with the DDR3 HMT
# table above (e.g. "112" = 1GB in both), which is expected - Hynix
# reused the same 3-digit density scheme across product generations.
HYNIX_DENSITY_HYMD = {
    "232": "256MB", "264": "512MB", "564": "512MB",
    "512": "1GB", "112": "1GB", "125": "2GB",
}


def decode_hynix(raw_value: str):
    pn = raw_value.strip().upper()
    result = {"manufacturer": "Hynix", "ram_type": None, "form_factor": None,
              "capacity": None, "speed": None}

    if pn.startswith("HMT"):
        result["ram_type"] = "DDR3"
        density_match = re.match(r"^HMT(\d{2}G|\d{2,3})", pn)
        if density_match and density_match.group(1) in HYNIX_DENSITY_HMT:
            result["capacity"] = HYNIX_DENSITY_HMT[density_match.group(1)]

        module_type_match = re.match(r"^HMT(?:\d{2}G|\d{2,3})[A-Z]{0,2}?([URS])", pn)
        if module_type_match:
            marker = module_type_match.group(1)
            if marker == "R":
                result["form_factor"] = "RDIMM (Server, Registered)"
            elif marker == "U":
                result["form_factor"] = "UDIMM (Desktop, Unbuffered)"
            elif marker == "S":
                result["form_factor"] = "SODIMM (Laptop)"
        elif result["capacity"] in ("16GB", "32GB"):
            result["form_factor"] = "RDIMM (Server, Registered) - inferred from capacity"
    elif pn.startswith(("HYMD", "HYMP")):
        result["ram_type"] = "DDR2"
        density_match = re.match(r"^HYM[DP](\d{3})", pn)
        if density_match and density_match.group(1) in HYNIX_DENSITY_HYMD:
            result["capacity"] = HYNIX_DENSITY_HYMD[density_match.group(1)]

        # Form factor marker sits right after the density digits, e.g.
        # HYMP125U64... = U (UDIMM), HYMP112S64... = S (SODIMM)
        form_match = re.match(r"^HYM[DP]\d{3}([USR])", pn)
        if form_match:
            marker = form_match.group(1)
            if marker == "U":
                result["form_factor"] = "UDIMM (Desktop, Unbuffered)"
            elif marker == "S":
                result["form_factor"] = "SODIMM (Laptop)"
            elif marker == "R":
                result["form_factor"] = "RDIMM (Server, Registered)"
        else:
            result["form_factor"] = "UDIMM (Desktop, Unbuffered)"
    elif pn.startswith("HY5"):
        result["ram_type"] = "DDR2"
    elif pn.startswith("H5"):
        result["ram_type"] = "DDR4"

    for suffix, speed in HYNIX_SPEED_SUFFIX.items():
        if f"-{suffix}" in pn or f" {suffix} " in f" {pn} ":
            result["speed"] = speed
            break

    result["part_number"] = raw_value.strip()
    result["raw_value"] = raw_value.strip()
    return result


def looks_like_hynix(raw: str) -> bool:
    val = raw.strip().upper()
    return val.startswith(("HMT", "HYMD", "HYMP", "HY5", "H5"))


# ============================================================================
# Micron
# ============================================================================
MICRON_WIDTH_DENSITY = {
    "25672": "2GB", "51272": "4GB", "1G72": "8GB", "12872": "1GB",
    "25664": "2GB", "51264": "4GB",
}
MICRON_SPEED_BIN = {
    "1G1": "PC3-8500 (DDR3-1066)", "1G4": "PC3-10600 (DDR3-1333)",
    "1G6": "PC3-12800 (DDR3-1600)", "1G8": "PC3-14900 (DDR3-1866)",
    "2G3": "DDR4-2400", "2G6": "DDR4-2666", "2G9": "DDR4-2933", "3G2": "DDR4-3200",
}
MICRON_PACKAGE = {
    "PZ": ("RDIMM (Server, Registered)", "DDR3"), "DZ": ("UDIMM (Desktop, Unbuffered)", "DDR3"),
    "FZ": ("SODIMM (Laptop)", "DDR3"), "GZ": ("UDIMM ECC (Desktop, Unbuffered ECC)", "DDR3"),
}

# DDR4-era Micron part numbers encode capacity as a COMBINATION of the
# leading chip-count number (right after "MTA") and the density block
# that follows the family code (ASF/ATF/etc) - the density block alone
# is NOT the capacity, since the same "1G72" density block appears on
# both an 8GB part (9 chips) and other capacities depending on chip
# count. Verified against multiple real, independently-listed Micron
# parts (retailer listings + Micron's own part-detail pages):
#   MTA9ASF1G72PZ...   = 8GB   (9 chips x 1Gb density, x72 ECC width)
#   MTA18ASF2G72PZ...  = 16GB  (18 chips x 2Gb density, x72 ECC width)
#   MTA4ATF1G64HZ...   = 8GB   (4 chips x 1Gb density, x64 non-ECC width, SODIMM)
#   MTA8ATF1G64HZ...   = 8GB   (8 chips x 1Gb density, x64 non-ECC width, SODIMM)
#   MTA8ATF2G64HZ...   = 16GB  (8 chips x 2Gb density, x64 non-ECC width, SODIMM)
#   MTA16ATF1G64HZ...  = 8GB   (16 chips x 1Gb density, x64 non-ECC width, SODIMM)
#   MTA16ATF2G64HZ...  = 16GB  (16 chips x 2Gb density, x64 non-ECC width, SODIMM)
MICRON_MTA_CAPACITY = {
    ("9", "1G72"): "8GB", ("18", "2G72"): "16GB", ("9", "2G72"): "16GB",
    ("4", "1G64"): "8GB", ("8", "1G64"): "8GB", ("16", "1G64"): "8GB",
    ("8", "2G64"): "16GB", ("16", "2G64"): "16GB", ("4", "2G64"): "16GB",
    ("4", "4G64"): "32GB", ("8", "4G64"): "32GB", ("16", "4G64"): "32GB",
}

MICRON_MTA_FORM_FACTOR = {
    "ASF": ("RDIMM (Server, Registered)", "DDR4"),
    "ATF": ("SODIMM (Laptop)", "DDR4"),
    "ADF": ("UDIMM (Desktop, Unbuffered)", "DDR4"),
    "AUF": ("UDIMM (Desktop, Unbuffered)", "DDR4"),
}


def decode_micron(raw_value: str):
    pn = raw_value.strip().upper()
    result = {"manufacturer": "Micron", "ram_type": None, "form_factor": None,
              "capacity": None, "speed": None}

    if pn.startswith("MTC"):
        result["ram_type"] = "DDR5"

    elif pn.startswith("MTA"):
        # Modern DDR4 naming: MTA<chip_count><family><density>...
        mta_match = re.match(r"^MTA(\d+)(ASF|ATF|ADF|AUF)(\d+G\d{2})", pn)
        if mta_match:
            chip_count, family, density = mta_match.groups()
            result["ram_type"] = "DDR4"
            if family in MICRON_MTA_FORM_FACTOR:
                form_factor, ram_type = MICRON_MTA_FORM_FACTOR[family]
                result["form_factor"] = form_factor
                result["ram_type"] = ram_type
            if (chip_count, density) in MICRON_MTA_CAPACITY:
                result["capacity"] = MICRON_MTA_CAPACITY[(chip_count, density)]

    else:
        # Older DDR3 naming: MT9/MT4/MT18... + density + PZ/DZ/FZ/GZ
        result["ram_type"] = "DDR3"
        density_match = re.search(r"MT\d?[A-Z]{0,4}(\d{3,5})(PZ|DZ|FZ|GZ)", pn)
        if density_match:
            density_code = density_match.group(1)
            package_code = density_match.group(2)
            if density_code in MICRON_WIDTH_DENSITY:
                result["capacity"] = MICRON_WIDTH_DENSITY[density_code]
            if package_code in MICRON_PACKAGE:
                form_factor, ram_type = MICRON_PACKAGE[package_code]
                result["form_factor"] = form_factor
                result["ram_type"] = ram_type

    speed_match = re.search(r"-(1G[0-9A-Z]|2G[0-9]|3G[0-9])", pn)
    if speed_match and speed_match.group(1) in MICRON_SPEED_BIN:
        result["speed"] = MICRON_SPEED_BIN[speed_match.group(1)]

    result["part_number"] = raw_value.strip()
    result["raw_value"] = raw_value.strip()
    return result


def looks_like_micron(raw: str) -> bool:
    val = raw.strip().upper()
    return val.startswith(("MT", "ASF"))



# ============================================================================
# Nanya
# ============================================================================
NANYA_SPEED_SUFFIX = {
    "5T": ("DDR", "PC3200 (DDR-400)"), "6K": ("DDR", "PC2700 (DDR-333)"),
    "7K": ("DDR", "PC2100 (DDR-266)"), "6T": ("DDR2", "PC2-5300 (DDR2-667)"),
    "5C": ("DDR2", "PC2-4200 (DDR2-533)"), "5J": ("DDR2", "PC2-6400 (DDR2-800)"),
}


def decode_nanya(raw_value: str):
    pn = raw_value.strip().upper()
    result = {"manufacturer": "Nanya", "ram_type": "DDR",
              "form_factor": "UDIMM (Desktop, Unbuffered)",
              "capacity": None, "speed": None}

    cap_match = re.match(r"^NT(\d+)", pn)
    if cap_match:
        mb = int(cap_match.group(1))
        result["capacity"] = f"{mb // 1024}GB" if mb >= 1024 else f"{mb}MB"

    if "-" in pn:
        speed_code = pn.split("-")[-1].strip()
        if speed_code in NANYA_SPEED_SUFFIX:
            ram_type, speed = NANYA_SPEED_SUFFIX[speed_code]
            result["ram_type"] = ram_type
            result["speed"] = speed

    result["part_number"] = raw_value.strip()
    result["raw_value"] = raw_value.strip()
    return result


def looks_like_nanya(raw: str) -> bool:
    return raw.strip().upper().startswith("NT")


def is_nanya_part_number(value: str) -> bool:
    """Nanya labels often have two barcodes; only the one starting with
    NT is the real part number (the other is a lot/trace code)."""
    return bool(re.match(r"^NT\d", value.strip().upper()))


# ============================================================================
# Kingston (all product lines, DDR-DDR5) - decoded from Kingston's own
# official published part-number decoder (kingston.com)
# ============================================================================
KINGSTON_SPEED_DDR5 = {
    "48": "4800", "52": "5200", "56": "5600", "60": "6000", "64": "6400",
    "68": "6800", "72": "7200", "76": "7600", "80": "8000", "84": "8400", "88": "8800",
}
KINGSTON_SPEED_DDR4 = {
    "16": "1600", "18": "1866", "21": "2133", "24": "2400", "26": "2666",
    "29": "2933", "32": "3200", "36": "3600", "37": "3733", "40": "4000",
    "42": "4266", "46": "4600", "48": "4800",
}
KINGSTON_CAPACITY = {
    "4": "4GB", "8": "8GB", "16": "16GB", "24": "24GB", "32": "32GB",
    "48": "48GB", "64": "64GB", "96": "96GB", "128": "128GB", "256": "256GB",
}


def decode_kingston(raw_value: str):
    pn = raw_value.strip().upper()
    result = {"manufacturer": "Kingston", "ram_type": None, "form_factor": None,
              "capacity": None, "speed": None}

    if pn.startswith("KF"):  # Kingston FURY
        gen_match = re.match(r"^KF([345])", pn)
        if gen_match:
            result["ram_type"] = {"3": "DDR3", "4": "DDR4", "5": "DDR5"}[gen_match.group(1)]
        if "C" in pn:
            result["form_factor"] = "UDIMM (Desktop, Unbuffered)"
        elif "S" in pn[:8]:
            result["form_factor"] = "SODIMM (Laptop)"
        cap_match = re.search(r"[-/](\d+)$", pn)
        if cap_match and cap_match.group(1) in KINGSTON_CAPACITY:
            result["capacity"] = KINGSTON_CAPACITY[cap_match.group(1)]

    elif pn.startswith("KSM"):  # Server Premier
        result["ram_type"] = "DDR4" if "R" in pn[3:7] else "DDR5"
        result["form_factor"] = "RDIMM (Server, Registered)"
        cap_match = re.search(r"/(\d+)", pn)
        if cap_match and cap_match.group(1) in KINGSTON_CAPACITY:
            result["capacity"] = KINGSTON_CAPACITY[cap_match.group(1)]

    elif pn.startswith("KVR"):  # ValueRAM
        speed_match = re.match(r"^KVR(\d{2})", pn)
        if speed_match:
            code = speed_match.group(1)
            # KVR is Kingston's oldest/longest-running line, spanning
            # DDR through DDR5. The same two-digit speed code can appear
            # in more than one generation's table (e.g. "16" means 1600
            # for DDR3 but doesn't exist as a DDR5 code), so check
            # DDR4 table first as the common case, then DDR5, falling
            # back to DDR3 for codes below the DDR4 range (DDR4 starts
            # at 1600 too, so the real distinguishing factor is whether
            # a low-voltage "L" marker or DDR3-only code range is used).
            if code in ("10", "13", "16") and "L" in pn[5:8]:
                result["ram_type"] = "DDR3"
            elif code in KINGSTON_SPEED_DDR5 and int(code) >= 48:
                result["ram_type"] = "DDR5"
            elif code in KINGSTON_SPEED_DDR4:
                result["ram_type"] = "DDR4" if int(code) >= 21 else "DDR3"
        if "N" in pn[5:8] or "U" in pn[5:8]:
            result["form_factor"] = "UDIMM (Desktop, Unbuffered)"
        elif "S" in pn[5:8]:
            result["form_factor"] = "SODIMM (Laptop)"
        elif "R" in pn[5:8]:
            result["form_factor"] = "RDIMM (Server, Registered)"
        cap_match = re.search(r"/(\d+)", pn)
        if cap_match and cap_match.group(1) in KINGSTON_CAPACITY:
            result["capacity"] = KINGSTON_CAPACITY[cap_match.group(1)]

    elif pn.startswith("CBD"):  # Design-In DRAM
        if "D3" in pn:
            result["ram_type"] = "DDR3"
        elif "D4" in pn:
            result["ram_type"] = "DDR4"
        else:
            result["ram_type"] = "DDR5"
        if "U" in pn[3:8]:
            result["form_factor"] = "UDIMM (Desktop, Unbuffered)"
        elif "S" in pn[3:8]:
            result["form_factor"] = "SODIMM (Laptop)"
        cap_match = re.search(r"[-/](\d+G?)$", pn)
        if cap_match:
            cap_raw = cap_match.group(1).rstrip("G")
            if cap_raw in KINGSTON_CAPACITY:
                result["capacity"] = KINGSTON_CAPACITY[cap_raw]

    result["part_number"] = raw_value.strip()
    result["raw_value"] = raw_value.strip()
    return result


def looks_like_kingston(raw: str) -> bool:
    val = raw.strip().upper()
    return val.startswith(("KF", "KSM", "KVR", "CBD", "HX", "KHX"))


# ============================================================================
# Crucial (a division of Micron; own CT/BL naming scheme)
# ============================================================================
def decode_crucial(raw_value: str):
    pn = raw_value.strip().upper()
    result = {"manufacturer": "Crucial", "ram_type": None, "form_factor": None,
              "capacity": None, "speed": None}

    # CT16G4SFD824A / CT8G4DFRA32A style: CT<capacity>G<gen>[form][width]...
    match = re.match(r"^(CT|BL)(\d+)G(\d)([SD]?)([A-Z]?)", pn)
    if match:
        prefix, cap, gen, form, _rest = match.groups()
        result["capacity"] = f"{cap}GB"
        result["ram_type"] = f"DDR{gen}"
        if form == "S":
            result["form_factor"] = "SODIMM (Laptop)"
        else:
            result["form_factor"] = "UDIMM (Desktop, Unbuffered)"

    result["part_number"] = raw_value.strip()
    result["raw_value"] = raw_value.strip()
    return result


def looks_like_crucial(raw: str) -> bool:
    val = raw.strip().upper()
    return val.startswith(("CT", "BL")) and bool(re.match(r"^(CT|BL)\d+G\d", val))


# ============================================================================
# Corsair (official decoder scheme, DDR-DDR5 confirmed via corsair.com)
# ============================================================================
CORSAIR_GEN = {"1": "DDR", "2": "DDR2", "3": "DDR3", "4": "DDR4", "5": "DDR5"}


def decode_corsair(raw_value: str):
    pn = raw_value.strip().upper()
    result = {"manufacturer": "Corsair", "ram_type": None,
              "form_factor": "UDIMM (Desktop, Unbuffered)",
              "capacity": None, "speed": None}

    # Format: CM<family><density>G<gen>M<qty>... - e.g. CMK32GX4M2A2666C16R
    # is a 32GB KIT across 2 modules (M2), so per-stick capacity is 16GB.
    # Simpler single-module format: CM...8G4... (no X-density kit marker).
    kit_match = re.search(r"(\d+)GX(\d)M(\d)", pn)
    if kit_match:
        total_gb = int(kit_match.group(1))
        module_count = int(kit_match.group(3))
        if module_count > 0:
            result["capacity"] = f"{total_gb // module_count}GB"
        gen_digit = kit_match.group(2)
        if gen_digit in CORSAIR_GEN:
            result["ram_type"] = CORSAIR_GEN[gen_digit]
    else:
        cap_match = re.search(r"(\d+)G(\d)", pn)
        if cap_match:
            result["capacity"] = f"{cap_match.group(1)}GB"
            gen_digit = cap_match.group(2)
            if gen_digit in CORSAIR_GEN:
                result["ram_type"] = CORSAIR_GEN[gen_digit]

    if "SO" in pn or pn.startswith("CMSX") or pn.startswith("CMSA"):
        result["form_factor"] = "SODIMM (Laptop)"

    speed_match = re.search(r"M\d[A-Z]?(\d{3,4})C", pn)
    if speed_match:
        result["speed"] = f"{speed_match.group(1)} MT/s"

    result["part_number"] = raw_value.strip()
    result["raw_value"] = raw_value.strip()
    return result


def looks_like_corsair(raw: str) -> bool:
    return raw.strip().upper().startswith("CM")


# ============================================================================
# Apacer - barcode is an internal SKU with no public decode scheme;
# specs come from OCR'd printed label text instead
# ============================================================================
APACER_TEXT_PATTERN = re.compile(
    r"(\d+)\s*(MB|GB)\s+([A-Z]+)?\s*PC(\d)-?(\d+)(?:\s*CL(\d+))?",
    re.IGNORECASE
)
APACER_FORM_FACTOR = {
    "UNB": "UDIMM (Desktop, Unbuffered)", "SO": "SODIMM (Laptop)",
    "REG": "RDIMM (Server, Registered)",
}
PC_GENERATION_TO_DDR = {"2": "DDR2", "3": "DDR3", "4": "DDR4", "5": "DDR5"}


def decode_apacer(raw_value: str, label_text: str = None):
    result = {"manufacturer": "Apacer", "ram_type": None, "form_factor": None,
              "capacity": None, "speed": None,
              "part_number": raw_value.strip(), "raw_value": raw_value.strip()}

    if label_text:
        match = APACER_TEXT_PATTERN.search(label_text)
        if match:
            cap_num, cap_unit, form_code, pc_gen, pc_speed, cl = match.groups()
            result["capacity"] = f"{cap_num}{cap_unit.upper()}"
            if form_code and form_code.upper() in APACER_FORM_FACTOR:
                result["form_factor"] = APACER_FORM_FACTOR[form_code.upper()]
            result["ram_type"] = PC_GENERATION_TO_DDR.get(pc_gen, f"DDR{pc_gen}")
            speed_str = f"PC{pc_gen}-{pc_speed}"
            if cl:
                speed_str += f" CL{cl}"
            result["speed"] = speed_str

    return result


def looks_like_apacer(raw: str) -> bool:
    # Real Apacer SKU format seen on labels: NN.NNNNN.NNN with the middle
    # block sometimes containing letters, e.g. "78.01GC6.420"
    return bool(re.match(r"^\d{2}\.[A-Z0-9]{5}\.\d{3}$", raw.strip().upper()))


def looks_like_lot_trace_code(raw: str) -> bool:
    """
    Detects generic lot/trace-code barcodes - the SECOND barcode often
    printed on a label alongside the real manufacturer part number
    (seen concretely on Nanya labels, e.g. '0513 MB0632302A
    6NMC769N02.S4 TW'). These encode a date code, factory batch, and
    country of origin rather than a decodable part number, and should
    be silently skipped rather than logged as an "unknown" stick -
    otherwise the user ends up with a wasted card slot every time their
    scanner happens to pick up the wrong barcode on a dual-barcode label.

    This used to only apply when the user had manually selected "Nanya"
    as the brand before scanning; now that brand selection is fully
    automatic, this generic shape-based check is what allows the app to
    recognize the same situation for any brand without being told first.

    Heuristic (kept deliberately narrow to avoid swallowing real part
    numbers): contains multiple space-separated segments, AND ends in a
    bare two-letter country code, AND does not start with any of the
    known manufacturer prefixes.
    """
    val = raw.strip().upper()
    segments = val.split()

    if len(segments) < 2:
        return False

    # Must end with a bare 2-letter code (e.g. TW, CN, KR, PH, MY) -
    # common on these labels to indicate country of assembly/origin
    if not re.match(r"^[A-Z]{2}$", segments[-1]):
        return False

    # If it matches any real manufacturer's shape, it's not a lot/trace
    # code even if it happens to end in two letters - let the real
    # decoder handle it instead.
    known_prefixes = ("M3", "M4", "HMT", "HYMD", "HYMP", "HY5", "H5", "MT",
                       "ASF", "NT", "KF", "KSM", "KVR", "CBD", "CT", "BL", "CM")
    if val.startswith(known_prefixes):
        return False

    return True


def decode_lot_trace_code(raw_value: str):
    """Returns a special marker result so the caller can distinguish
    'skip this silently' from a genuine unknown stick."""
    return {
        "manufacturer": None,
        "part_number": raw_value.strip(),
        "ram_type": None,
        "form_factor": None,
        "capacity": None,
        "speed": None,
        "raw_value": raw_value.strip(),
        "is_lot_trace_code": True,
    }


# ============================================================================
# Auto-detect dispatch
# ============================================================================
# Order matters: more specific/distinctive patterns first to avoid a
# generic prefix from one brand accidentally matching another. The
# lot/trace-code check runs LAST, only after every real brand pattern
# has had a chance to match, so it can never shadow a genuine part number.
_DETECTORS = [
    (looks_like_kingston, decode_kingston),
    (looks_like_crucial, decode_crucial),
    (looks_like_corsair, decode_corsair),
    (looks_like_samsung, decode_samsung),
    (looks_like_hynix, decode_hynix),
    (looks_like_micron, decode_micron),
    (looks_like_nanya, decode_nanya),
    (looks_like_apacer, decode_apacer),
    (looks_like_lot_trace_code, decode_lot_trace_code),
]


def decode_auto(raw_value: str, label_text: str = None):
    """
    Main entry point. Tries every known brand's pattern against the
    scanned value and returns the first confident match. If nothing
    matches, returns an "Unknown" result with every field blank so the
    caller can prompt the user to fill in details manually. If the
    value looks like a lot/trace code (a secondary barcode on the same
    label as a real part number, not a decodable part number itself),
    returns a result flagged with is_lot_trace_code=True so the caller
    can skip logging it entirely instead of treating it as an unknown
    stick.
    """
    raw = raw_value.strip()

    for detector, decoder in _DETECTORS:
        if detector(raw):
            if decoder is decode_apacer:
                return decoder(raw, label_text=label_text)
            return decoder(raw)

    return {
        "manufacturer": None,
        "part_number": raw,
        "ram_type": None,
        "form_factor": None,
        "capacity": None,
        "speed": None,
        "raw_value": raw,
    }


def decode_with_brand_hint(raw_value: str, brand_hint: str, label_text: str = None):
    """Force decoding through a specific brand's decoder, used when the
    user manually corrects/confirms a brand after auto-detect missed it
    or got it wrong."""
    brand_map = {
        "Samsung": decode_samsung, "Hynix": decode_hynix, "Micron": decode_micron,
        "Nanya": decode_nanya, "Kingston": decode_kingston, "Crucial": decode_crucial,
        "Corsair": decode_corsair,
    }
    if brand_hint == "Apacer":
        return decode_apacer(raw_value, label_text=label_text)
    if brand_hint in brand_map:
        return brand_map[brand_hint](raw_value)
    return decode_auto(raw_value, label_text=label_text)


if __name__ == "__main__":
    tests = [
        "M378B5273CH0-CH9 1136",           # Samsung 4GB DDR3
        "MT9JSF25672PZ-1G6K1FF 1342",      # Micron 2GB DDR3 RDIMM
        "HMT32GF8AFR8A-G7 VT AA J143",     # Hynix 16GB DDR3 server
        "NT256D64S88C0GY-5T",              # Nanya 256MB DDR
        "KVR16LN11/8",                     # Kingston ValueRAM DDR3 8GB
        "KF432C16BB1/16",                  # Kingston FURY DDR4
        "CT16G4SFD824A",                   # Crucial 16GB DDR4 SODIMM
        "CMK32GX4M2A2666C16R",             # Corsair DDR4 32GB kit
        "78.01GC6.420",                    # Apacer (needs label_text)
        "TOTALLYUNKNOWNCODE999",
    ]
    for t in tests:
        print(t, "->", decode_auto(t, label_text="1GB UNB PC3-10600 CL9" if "78.01" in t else None))
