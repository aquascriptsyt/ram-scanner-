"""
STS Rams - Desktop app entry point
-------------------------------------
Runs the Flask backend on 127.0.0.1 (never exposed to the network) and
opens it in a native desktop window via pywebview - no browser tab, no
ngrok, no phone required. This is what employees actually double-click
to run the app.

Requirements:
    pip install flask openpyxl pywebview

Run:
    python main.py
"""

import os
import sys
import threading
import time

import webview

from server import app, run_server
import sheets


def _resource_path(relative_path):
    """Resolves a bundled resource path correctly whether running as a
    normal script or as the PyInstaller-built .exe (see server.py's
    RESOURCE_FOLDER for the same logic, used for Flask's templates)."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        base = sys._MEIPASS
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, relative_path)


def _start_flask_background():
    """Runs the Flask server in a background thread so the webview
    window can own the main thread (required on some platforms)."""
    run_server(port=5757)


def _on_window_closing():
    """Final safety net: force-save whatever's in memory the moment the
    window starts closing, on top of the save-on-every-scan behavior
    and the JS beforeunload handler."""
    try:
        sheets.force_save()
        print("Final save completed on window close.")
    except Exception as e:
        print(f"Warning: final save on close failed ({e}). Data up to the last "
              f"successful scan is still on disk.")


def main():
    flask_thread = threading.Thread(target=_start_flask_background, daemon=True)
    flask_thread.start()

    # Give Flask a moment to bind the port before pointing the window at it
    time.sleep(0.8)

    window = webview.create_window(
        "STS Rams",
        "http://127.0.0.1:5757",
        width=1280,
        height=820,
        min_size=(1000, 650),
        background_color="#0b0d10",
    )
    window.events.closing += _on_window_closing

    icon_path = _resource_path(os.path.join("assets", "logo.ico"))
    if os.path.exists(icon_path):
        webview.start(icon=icon_path)
    else:
        webview.start()


if __name__ == "__main__":
    main()
