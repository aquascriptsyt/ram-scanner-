"""
STS Rams - Local application server
--------------------------------------
Runs on 127.0.0.1 only (never exposed to the network - this is a local
desktop app, not a hosted service). Serves the frontend and handles
every action: login, auto-detect scanning, sheet management, and the
admin code-generation panel.
"""

import os
import sys
import time
import threading

from flask import Flask, render_template, request, jsonify

import auth
import sheets
import settings
from ram_decoder import decode_auto, decode_with_brand_hint

FOLDER = os.path.dirname(os.path.abspath(__file__))

# When packaged into a .exe with PyInstaller (via "Build App.bat"),
# bundled files (templates/, static/) are extracted at runtime into a
# temporary folder pointed to by sys._MEIPASS - Flask needs to be told
# to look there instead of next to this script. When just running as a
# normal .py file (no build), sys._MEIPASS doesn't exist and FOLDER is
# used as before.
if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    RESOURCE_FOLDER = sys._MEIPASS
else:
    RESOURCE_FOLDER = FOLDER

app = Flask(
    __name__,
    template_folder=os.path.join(RESOURCE_FOLDER, "templates"),
    static_folder=os.path.join(RESOURCE_FOLDER, "static"),
)
app.secret_key = os.urandom(24).hex()  # session cookie signing key, regenerated each launch (fine - this is a single-user local app)

recent_scans = {}
RECENT_SCANS_MAX_AGE_SECONDS = 30
DUPLICATE_COOLDOWN_SECONDS = 5
_scan_lock = threading.Lock()


@app.errorhandler(Exception)
def handle_any_error(e):
    """Last line of defense: no unhandled exception can crash the
    local server process. Logs to console, returns a clean JSON error."""
    import traceback
    print("=" * 60)
    print("UNHANDLED ERROR (app is still running, this request failed):")
    traceback.print_exc()
    print("=" * 60)
    return jsonify({"status": "error", "message": f"Something went wrong: {str(e)}. Try again."}), 200


def _prune_recent_scans():
    now = time.time()
    expired = [k for k, t in recent_scans.items() if (now - t) > RECENT_SCANS_MAX_AGE_SECONDS]
    for k in expired:
        del recent_scans[k]


# ============================================================================
# Page routes
# ============================================================================
@app.route("/")
def index():
    return render_template("app.html")


# ============================================================================
# Auth API
# ============================================================================
@app.route("/api/auth/status", methods=["GET"])
def api_auth_status():
    employee_name = auth.get_active_session()
    if employee_name is not None:
        # A session was already saved on this computer (e.g. app was
        # closed and reopened) - restore whichever sheet was most
        # recently worked on instead of leaving no sheet active at all.
        current_state = sheets.get_state()
        if not current_state.get("sheet_name"):
            most_recent = sheets.get_most_recently_modified_sheet()
            if most_recent:
                try:
                    sheets.select_existing_sheet(most_recent)
                except Exception:
                    pass  # fall through - worst case, sheet stays unset and the user can pick one manually
    return jsonify({"logged_in": employee_name is not None, "employee_name": employee_name})


@app.route("/api/auth/login", methods=["POST"])
def api_auth_login():
    data = request.get_json(force=True, silent=True) or {}
    employee_name = (data.get("employee_name") or "").strip()

    if not employee_name:
        return jsonify({"status": "error", "message": "Please enter your name."}), 200

    saved_name = auth.start_session(employee_name)
    filename = sheets.create_sheet_for_login(saved_name)
    return jsonify({"status": "ok", "employee_name": saved_name, "sheet": filename})


@app.route("/api/auth/logout", methods=["POST"])
def api_auth_logout():
    auth.clear_session()
    return jsonify({"status": "ok"})





# ============================================================================
# Scanning API
# ============================================================================
@app.route("/api/scan", methods=["POST"])
def api_scan():
    data = request.get_json(force=True, silent=True) or {}
    value = (data.get("value") or "").strip()
    brand_hint = data.get("brand_hint")  # only set when user corrects a wrong auto-detect
    label_text = data.get("label_text")

    if not value:
        return jsonify({"status": "error", "message": "No value provided"}), 400

    state = sheets.get_state()
    if not state["ram_type_set"]:
        return jsonify({"status": "ram_type_required", "message": "Set the RAM type for this session before scanning."}), 200

    with _scan_lock:
        _prune_recent_scans()
        now = time.time()
        last_seen = recent_scans.get(value)
        if last_seen is not None and (now - last_seen) < DUPLICATE_COOLDOWN_SECONDS:
            return jsonify({"status": "duplicate", "message": "Already logged recently"}), 200
        recent_scans[value] = now

        if brand_hint:
            decoded = decode_with_brand_hint(value, brand_hint, label_text=label_text)
        else:
            decoded = decode_auto(value, label_text=label_text)

        # Generic lot/trace-code handling: some labels (seen concretely
        # on Nanya) print TWO barcodes - the real part number and a
        # date/batch/origin trace code. Silently skip the trace code
        # rather than logging it as an "unknown" stick and wasting a
        # card slot; the scanner just keeps listening for the real one.
        if decoded.get("is_lot_trace_code"):
            return jsonify({
                "status": "ignored",
                "message": "That looks like a lot/trace barcode, not a part number - keep scanning for the real part number.",
            }), 200

        entry = sheets.log_entry(decoded)

        all_missing = [k for k in ("Manufacturer", "Part Number", "RAM Type", "Form Factor", "Capacity", "Speed") if not entry.get(k)]
        missing_fields = settings.filter_missing_fields(all_missing)
        needs_warning = len(missing_fields) > 0

        return jsonify({
            "status": "ok",
            "entry": entry,
            "needs_warning": needs_warning,
            "missing_fields": missing_fields,
        })


@app.route("/api/manual", methods=["POST"])
def api_manual():
    data = request.get_json(force=True, silent=True) or {}
    value = (data.get("value") or "").strip()
    brand_hint = data.get("brand_hint")
    label_text = data.get("label_text")

    if not value:
        return jsonify({"status": "error", "message": "No value provided"}), 400

    state = sheets.get_state()
    if not state["ram_type_set"]:
        return jsonify({"status": "ram_type_required", "message": "Set the RAM type for this session before adding entries."}), 200

    if brand_hint:
        decoded = decode_with_brand_hint(value, brand_hint, label_text=label_text)
    else:
        decoded = decode_auto(value, label_text=label_text)

    entry = sheets.log_entry(decoded)
    all_missing = [k for k in ("Manufacturer", "Part Number", "RAM Type", "Form Factor", "Capacity", "Speed") if not entry.get(k)]
    missing_fields = settings.filter_missing_fields(all_missing)
    needs_warning = len(missing_fields) > 0

    return jsonify({"status": "ok", "entry": entry, "needs_warning": needs_warning, "missing_fields": missing_fields})


@app.route("/api/fix_entry", methods=["POST"])
def api_fix_entry():
    data = request.get_json(force=True, silent=True) or {}
    try:
        entry = sheets.fix_last_entry(data)
        return jsonify({"status": "ok", "entry": entry})
    except ValueError as e:
        return jsonify({"status": "error", "message": str(e)}), 200


@app.route("/api/delete", methods=["POST"])
def api_delete():
    data = request.get_json(force=True, silent=True) or {}
    group = data.get("group")
    index = data.get("index")
    if group is None or index is None:
        return jsonify({"status": "error", "message": "No group/index provided"}), 400
    sheets.delete_entry(group, index)
    return jsonify({"status": "ok"})


@app.route("/api/state", methods=["GET"])
def api_state():
    return jsonify(sheets.get_state())


@app.route("/api/ram_type", methods=["POST"])
def api_ram_type():
    data = request.get_json(force=True, silent=True) or {}
    ram_type = (data.get("ram_type") or "").strip()
    if not ram_type:
        return jsonify({"status": "error", "message": "RAM type cannot be empty."}), 200
    sheets.set_ram_type(ram_type)
    return jsonify({"status": "ok"})


@app.route("/api/package/save", methods=["POST"])
def api_package_save():
    data = request.get_json(force=True, silent=True) or {}
    package_number = data.get("package_number")
    result = sheets.save_package(package_number_override=package_number)
    return jsonify({"status": "ok", **result})


# ============================================================================
# Sheet browsing (view-only list of all past sheets; the active sheet is
# always the current login session's sheet, per the "new sheet per login" spec)
# ============================================================================
@app.route("/api/settings", methods=["GET"])
def api_settings_get():
    return jsonify(settings.get_settings())


@app.route("/api/settings", methods=["POST"])
def api_settings_update():
    data = request.get_json(force=True, silent=True) or {}
    updated = settings.update_settings(data)
    return jsonify({"status": "ok", "settings": updated})


@app.route("/api/sheets", methods=["GET"])
def api_sheets_list():
    return jsonify({"sheets": sheets.list_all_sheets(), "active_sheet": sheets.get_state()["sheet_name"]})


@app.route("/api/sheets/select", methods=["POST"])
def api_sheets_select():
    data = request.get_json(force=True, silent=True) or {}
    filename = (data.get("filename") or "").strip()
    if not filename:
        return jsonify({"status": "error", "message": "No filename provided"}), 400
    try:
        state = sheets.select_existing_sheet(filename)
        return jsonify({"status": "ok", "state": state})
    except FileNotFoundError as e:
        return jsonify({"status": "error", "message": str(e)}), 200


@app.route("/api/sheets/create", methods=["POST"])
def api_sheets_create():
    data = request.get_json(force=True, silent=True) or {}
    sheet_label = (data.get("sheet_label") or "").strip()
    if not sheet_label:
        return jsonify({"status": "error", "message": "Please give the new sheet a name."}), 200

    current_state = sheets.get_state()
    logged_by = current_state.get("logged_by") or "Unknown"
    filename = sheets.create_new_sheet(sheet_label, logged_by)
    return jsonify({"status": "ok", "filename": filename})


@app.route("/api/sheets/delete", methods=["POST"])
def api_sheets_delete():
    data = request.get_json(force=True, silent=True) or {}
    filename = (data.get("filename") or "").strip()
    password = data.get("password", "")

    if not filename:
        return jsonify({"status": "error", "message": "No filename provided"}), 400
    if not auth.check_delete_password(password):
        return jsonify({"status": "error", "message": "Incorrect manager password."}), 200

    try:
        sheets.delete_sheet(filename)
        return jsonify({"status": "ok"})
    except FileNotFoundError as e:
        return jsonify({"status": "error", "message": str(e)}), 200


# ============================================================================
# App shutdown - force a final save
# ============================================================================
@app.route("/api/shutdown_save", methods=["POST"])
def api_shutdown_save():
    """Called by the frontend right before the window closes, as a
    final safety net on top of the save-on-every-scan behavior."""
    ok = sheets.force_save()
    return jsonify({"status": "ok" if ok else "save_failed"})


def run_server(port=5757):
    app.run(host="127.0.0.1", port=port, debug=False, threaded=True, use_reloader=False)


if __name__ == "__main__":
    run_server()
