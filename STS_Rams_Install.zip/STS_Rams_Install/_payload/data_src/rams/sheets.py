"""
STS Rams - Sheet management
-----------------------------
Manages Excel log sheets: creating a new sheet per login session,
selecting/continuing an existing sheet, the Package/Card countdown
numbering, and safe saving that can't crash the app even if the file
is locked or something goes wrong mid-write.

Layout: each sheet is split into dedicated sections for DDR, DDR2,
DDR3, DDR4, DDR5, and Other (anything that doesn't map to a DDR
generation cleanly). Each scan is tagged with the generation active
at the time it was logged - this can be changed mid-session, so a
single sheet can hold a mix of generations, each in its own section,
each with a running subtotal, plus a grand total at the very bottom.
"""

import os
import re
import threading
from datetime import datetime

import openpyxl
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

import paths

SHEETS_FOLDER = paths.SHEETS_FOLDER

ENTRY_COLUMNS = [
    "Package Number",
    "Card Number",
    "Raw Barcode Value",
    "Manufacturer",
    "Part Number",
    "RAM Type",
    "Form Factor",
    "Capacity",
    "Speed",
]

DDR_GROUPS = ["DDR", "DDR2", "DDR3", "DDR4", "DDR5", "Other"]

CARDS_PER_PACKAGE = 10

_lock = threading.Lock()

_state = {
    "sheet_name": None,
    "logged_by": "",
    "current_ram_type": "",
    "current_package_number": 1,
    "current_card_number": CARDS_PER_PACKAGE,
    "groups": {g: [] for g in DDR_GROUPS},
}


def _safe_filename(name: str) -> str:
    name = name.strip()
    name = re.sub(r"[^A-Za-z0-9 _\-]", "", name)
    name = re.sub(r"\s+", "_", name)
    return name or "Untitled"


def _sheet_path(filename: str) -> str:
    return os.path.join(SHEETS_FOLDER, filename)


def _classify_ddr_group(ram_type_label: str) -> str:
    """Maps a free-text RAM type (e.g. 'DDR3', 'ddr3 server batch',
    'PC3-10600') to one of the 5 DDR sections, or 'Other' if it can't
    be confidently classified."""
    label = (ram_type_label or "").upper()

    if re.search(r"\bDDR\s*5\b", label) or "PC5" in label:
        return "DDR5"
    if re.search(r"\bDDR\s*4\b", label) or "PC4" in label:
        return "DDR4"
    if re.search(r"\bDDR\s*3\b", label) or "PC3" in label:
        return "DDR3"
    if re.search(r"\bDDR\s*2\b", label) or "PC2" in label:
        return "DDR2"
    if "DDR" in label:
        return "DDR"
    return "Other"


def create_sheet_for_login(employee_name: str) -> str:
    safe_name = _safe_filename(employee_name) or "Unknown"
    timestamp_part = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{safe_name}_{timestamp_part}.xlsx"

    with _lock:
        _state["sheet_name"] = filename
        _state["logged_by"] = employee_name
        _state["current_ram_type"] = ""
        _state["current_package_number"] = 1
        _state["current_card_number"] = CARDS_PER_PACKAGE
        _state["groups"] = {g: [] for g in DDR_GROUPS}
        _save_active_sheet_locked()

    return filename


def create_new_sheet(sheet_label: str, logged_by: str) -> str:
    """
    Creates a brand new sheet on demand (from the Excel Editor tab, not
    tied to a login event) and makes it the active one. sheet_label is
    a free-text name the user gives it, e.g. "Warehouse B - August".
    """
    safe_label = _safe_filename(sheet_label) or "New_Sheet"
    timestamp_part = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{safe_label}_{timestamp_part}.xlsx"

    with _lock:
        _state["sheet_name"] = filename
        _state["logged_by"] = logged_by
        _state["current_ram_type"] = ""
        _state["current_package_number"] = 1
        _state["current_card_number"] = CARDS_PER_PACKAGE
        _state["groups"] = {g: [] for g in DDR_GROUPS}
        _save_active_sheet_locked()

    return filename


def delete_sheet(filename: str):
    """Permanently deletes a sheet file. Caller (server.py) is
    responsible for the manager-password gate before calling this -
    this function itself does not check any password, it just deletes."""
    path = _sheet_path(filename)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Sheet not found: {filename}")
    os.remove(path)

    with _lock:
        if _state["sheet_name"] == filename:
            # The active sheet was just deleted - clear state so the
            # app doesn't keep writing to a file that no longer exists.
            _state["sheet_name"] = None
            _state["logged_by"] = ""
            _state["current_ram_type"] = ""
            _state["current_package_number"] = 1
            _state["current_card_number"] = CARDS_PER_PACKAGE
            _state["groups"] = {g: [] for g in DDR_GROUPS}


def select_existing_sheet(filename: str) -> dict:
    """Switches the active sheet to an existing file and continues
    appending to it - reloads every section's entries and resumes the
    package/card counters from the highest-numbered entry found."""
    path = _sheet_path(filename)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Sheet not found: {filename}")

    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.active

    logged_by = ws.cell(row=1, column=2).value or ""

    groups = {g: [] for g in DDR_GROUPS}
    max_package = 1
    max_card_for_max_package = None

    row = 1
    max_row = ws.max_row
    while row <= max_row:
        cell_a = ws.cell(row=row, column=1).value
        if isinstance(cell_a, str) and cell_a.strip() in DDR_GROUPS:
            group_name = cell_a.strip()
            header_row = row + 1
            data_row = header_row + 1
            while data_row <= max_row:
                first_cell = ws.cell(row=data_row, column=1).value
                if first_cell is None or (isinstance(first_cell, str) and first_cell.strip() == ""):
                    break
                if isinstance(first_cell, str) and first_cell.strip() in DDR_GROUPS:
                    break
                entry = {}
                for i, col in enumerate(ENTRY_COLUMNS, start=1):
                    val = ws.cell(row=data_row, column=i).value
                    entry[col] = val if val is not None else ""
                if any(str(v).strip() for v in entry.values()):
                    groups[group_name].append(entry)
                    try:
                        pkg = int(entry.get("Package Number") or 0)
                        card = int(entry.get("Card Number") or 0)
                        if pkg >= max_package:
                            max_package = pkg
                            max_card_for_max_package = card
                    except (TypeError, ValueError):
                        pass
                data_row += 1
            row = data_row
            continue
        row += 1

    with _lock:
        _state["sheet_name"] = filename
        _state["logged_by"] = logged_by
        _state["current_ram_type"] = ""
        _state["groups"] = groups
        if max_card_for_max_package is None:
            _state["current_package_number"] = 1
            _state["current_card_number"] = CARDS_PER_PACKAGE
        elif max_card_for_max_package > 1:
            _state["current_package_number"] = max_package
            _state["current_card_number"] = max_card_for_max_package - 1
        else:
            _state["current_package_number"] = max_package + 1
            _state["current_card_number"] = CARDS_PER_PACKAGE

    return get_state()


def set_ram_type(ram_type: str):
    """Sets the RAM type currently being scanned. Can be changed mid-
    session as many times as needed."""
    with _lock:
        _state["current_ram_type"] = ram_type.strip()
        _save_active_sheet_locked()


def get_state():
    with _lock:
        all_entries = []
        for group in DDR_GROUPS:
            for e in _state["groups"][group]:
                all_entries.append({**e, "_group": group})
        all_entries_reversed = list(reversed(all_entries))

        totals = {g: len(_state["groups"][g]) for g in DDR_GROUPS}
        grand_total = sum(totals.values())

        return {
            "sheet_name": _state["sheet_name"],
            "logged_by": _state["logged_by"],
            "ram_type": _state["current_ram_type"],
            "current_package_number": _state["current_package_number"],
            "current_card_number": _state["current_card_number"],
            "entries": all_entries_reversed,
            "ram_type_set": bool(_state["current_ram_type"]),
            "totals": totals,
            "grand_total": grand_total,
        }


def log_entry(decoded: dict) -> dict:
    with _lock:
        group = _classify_ddr_group(_state["current_ram_type"])

        entry = {
            "Package Number": _state["current_package_number"],
            "Card Number": _state["current_card_number"],
            "Raw Barcode Value": decoded.get("raw_value", ""),
            "Manufacturer": decoded.get("manufacturer") or "",
            "Part Number": decoded.get("part_number", ""),
            "RAM Type": decoded.get("ram_type") or _state["current_ram_type"],
            "Form Factor": decoded.get("form_factor") or "",
            "Capacity": decoded.get("capacity") or "",
            "Speed": decoded.get("speed") or "",
        }
        _state["groups"][group].append(entry)

        if _state["current_card_number"] > 1:
            _state["current_card_number"] -= 1
        else:
            _state["current_package_number"] += 1
            _state["current_card_number"] = CARDS_PER_PACKAGE

        _save_active_sheet_locked()
        return {**entry, "_group": group}


def fix_last_entry(fields: dict) -> dict:
    with _lock:
        last_group = None
        for group in DDR_GROUPS:
            if _state["groups"][group]:
                last_group = group
        if last_group is None:
            raise ValueError("No entries to update")

        entry = _state["groups"][last_group][-1]
        field_map = {
            "manufacturer": "Manufacturer", "part_number": "Part Number",
            "ram_type": "RAM Type", "form_factor": "Form Factor",
            "capacity": "Capacity", "speed": "Speed",
        }
        for key, col in field_map.items():
            value = (fields.get(key) or "").strip()
            if value:
                entry[col] = value
        _save_active_sheet_locked()
        return {**entry, "_group": last_group}


def delete_entry(group: str, group_index: int):
    with _lock:
        if group not in _state["groups"]:
            return
        entries = _state["groups"][group]
        real_index = len(entries) - 1 - group_index
        if not (0 <= real_index < len(entries)):
            return
        deleted = entries[real_index]
        del entries[real_index]

        try:
            deleted_package = int(deleted.get("Package Number") or 0)
            deleted_card = int(deleted.get("Card Number") or 0)
        except (TypeError, ValueError):
            deleted_package, deleted_card = 0, 0

        if deleted_package == _state["current_package_number"] and deleted_card > _state["current_card_number"]:
            _state["current_card_number"] = deleted_card

        _save_active_sheet_locked()


def save_package(package_number_override=None) -> dict:
    with _lock:
        finished_package = _state["current_package_number"]

        if package_number_override:
            try:
                _state["current_package_number"] = int(package_number_override)
            except (TypeError, ValueError):
                _state["current_package_number"] += 1
        else:
            _state["current_package_number"] += 1

        _state["current_card_number"] = CARDS_PER_PACKAGE
        _save_active_sheet_locked()

        return {
            "finished_package": finished_package,
            "new_package_number": _state["current_package_number"],
            "new_card_number": _state["current_card_number"],
        }


SECTION_FILL = {
    "DDR": PatternFill(start_color="2E3A2E", end_color="2E3A2E", fill_type="solid"),
    "DDR2": PatternFill(start_color="2E3540", end_color="2E3540", fill_type="solid"),
    "DDR3": PatternFill(start_color="343050", end_color="343050", fill_type="solid"),
    "DDR4": PatternFill(start_color="402E3E", end_color="402E3E", fill_type="solid"),
    "DDR5": PatternFill(start_color="402E2E", end_color="402E2E", fill_type="solid"),
    "Other": PatternFill(start_color="3A3A3A", end_color="3A3A3A", fill_type="solid"),
}
TOTALS_FILL = PatternFill(start_color="1F2A1F", end_color="1F2A1F", fill_type="solid")


def _save_active_sheet_locked():
    if not _state["sheet_name"]:
        return False

    path = _sheet_path(_state["sheet_name"])
    try:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "RAM Log"

        ws.cell(row=1, column=1).value = "Logged By:"
        ws.cell(row=1, column=1).font = Font(bold=True)
        ws.cell(row=1, column=2).value = _state["logged_by"]

        ws.cell(row=2, column=1).value = "Currently Logging:"
        ws.cell(row=2, column=1).font = Font(bold=True)
        ws.cell(row=2, column=2).value = _state["current_ram_type"]

        row = 4
        max_col_widths = [len(c) for c in ENTRY_COLUMNS]

        for group in DDR_GROUPS:
            entries = _state["groups"][group]
            if not entries:
                continue

            title_cell = ws.cell(row=row, column=1)
            title_cell.value = group
            title_cell.font = Font(bold=True, size=13, color="FFFFFF")
            for c in range(1, len(ENTRY_COLUMNS) + 1):
                ws.cell(row=row, column=c).fill = SECTION_FILL.get(group, SECTION_FILL["Other"])
            row += 1

            for i, col in enumerate(ENTRY_COLUMNS, start=1):
                cell = ws.cell(row=row, column=i)
                cell.value = col
                cell.font = Font(bold=True)
            row += 1

            for entry in entries:
                for i, col in enumerate(ENTRY_COLUMNS, start=1):
                    val = entry.get(col, "")
                    ws.cell(row=row, column=i).value = val
                    max_col_widths[i - 1] = max(max_col_widths[i - 1], len(str(val)))
                row += 1

            row += 1

        row += 1
        totals_title = ws.cell(row=row, column=1)
        totals_title.value = "TOTALS"
        totals_title.font = Font(bold=True, size=13, color="FFFFFF")
        totals_title.fill = TOTALS_FILL
        row += 1

        grand_total = 0
        for group in DDR_GROUPS:
            count = len(_state["groups"][group])
            if count == 0:
                continue
            ws.cell(row=row, column=1).value = group
            ws.cell(row=row, column=1).font = Font(bold=True)
            ws.cell(row=row, column=2).value = count
            grand_total += count
            row += 1

        row += 1
        ws.cell(row=row, column=1).value = "GRAND TOTAL"
        ws.cell(row=row, column=1).font = Font(bold=True, size=12)
        ws.cell(row=row, column=2).value = grand_total
        ws.cell(row=row, column=2).font = Font(bold=True, size=12)

        for i in range(1, len(ENTRY_COLUMNS) + 1):
            ws.column_dimensions[get_column_letter(i)].width = max_col_widths[i - 1] + 4

        wb.save(path)
        return True
    except Exception as e:
        print(f"WARNING: could not save sheet ({e}). Data is still safe in memory; "
              f"will retry on the next scan or on app close.")
        return False


def force_save() -> bool:
    with _lock:
        return _save_active_sheet_locked()


def get_most_recently_modified_sheet():
    """Returns the filename of whichever sheet was written to most
    recently (by file modification time), or None if there are no
    sheets yet. Used to restore the active sheet on app reopen, so a
    closed-and-reopened app resumes into the same sheet instead of
    having no active sheet at all."""
    if not os.path.exists(SHEETS_FOLDER):
        return None
    candidates = [f for f in os.listdir(SHEETS_FOLDER) if f.lower().endswith(".xlsx")]
    if not candidates:
        return None
    candidates.sort(key=lambda f: os.path.getmtime(_sheet_path(f)), reverse=True)
    return candidates[0]


def list_all_sheets() -> list:
    results = []
    if not os.path.exists(SHEETS_FOLDER):
        return results
    for fname in sorted(os.listdir(SHEETS_FOLDER)):
        if not fname.lower().endswith(".xlsx"):
            continue
        path = _sheet_path(fname)
        try:
            wb = openpyxl.load_workbook(path, data_only=True)
            ws = wb.active
            logged_by = ws.cell(row=1, column=2).value or ""

            entry_count = 0
            row = 1
            max_row = ws.max_row
            while row <= max_row:
                cell_a = ws.cell(row=row, column=1).value
                if isinstance(cell_a, str) and cell_a.strip() in DDR_GROUPS:
                    data_row = row + 2
                    while data_row <= max_row:
                        first_cell = ws.cell(row=data_row, column=1).value
                        if first_cell is None or (isinstance(first_cell, str) and first_cell.strip() == ""):
                            break
                        if isinstance(first_cell, str) and first_cell.strip() in DDR_GROUPS:
                            break
                        entry_count += 1
                        data_row += 1
                    row = data_row
                    continue
                row += 1

            results.append({
                "filename": fname,
                "logged_by": logged_by,
                "entry_count": entry_count,
            })
        except Exception:
            continue
    return results
