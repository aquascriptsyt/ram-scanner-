"""
STS Rams - Session and delete-password handling
---------------------------------------------------
No login codes, no admin password - each computer just remembers who's
using it locally (a name, for the Excel sheet), saved in the Data
folder so it survives app restarts. Signing out just clears that name
and asks again next launch.

The one password kept is the sheet-delete password - a fixed
confirmation gate for a destructive action, unrelated to login.
"""

import os
import json

import paths

SESSION_PATH = os.path.join(paths.DATA_FOLDER, "session_employee.json")

DELETE_SHEET_PASSWORD = "DEL-Z3XA563PZE4RAZY"


def check_delete_password(password: str) -> bool:
    return password.strip() == DELETE_SHEET_PASSWORD


def start_session(employee_name: str) -> str:
    employee_name = employee_name.strip()
    with open(SESSION_PATH, "w") as f:
        json.dump({"employee_name": employee_name}, f, indent=2)
    return employee_name


def get_active_session():
    if not os.path.exists(SESSION_PATH):
        return None
    try:
        with open(SESSION_PATH, "r") as f:
            session = json.load(f)
        name = (session.get("employee_name") or "").strip()
        return name or None
    except (json.JSONDecodeError, IOError):
        return None


def clear_session():
    if os.path.exists(SESSION_PATH):
        os.remove(SESSION_PATH)
