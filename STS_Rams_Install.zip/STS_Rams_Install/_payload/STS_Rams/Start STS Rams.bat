@echo off
setlocal enabledelayedexpansion
set "CODE_DIR=%~dp0..\..\STS Scanner Data\src_rams"
cd /d "%CODE_DIR%"

set "PYEXE="
where pythonw >nul 2>nul
if %errorlevel% == 0 (
    for /f "delims=" %%P in ('where pythonw') do (
        echo %%P | findstr /i "WindowsApps" >nul
        if errorlevel 1 (
            if not defined PYEXE set "PYEXE=%%P"
        )
    )
)
if not defined PYEXE (
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
        if exist "%%D\pythonw.exe" set "PYEXE=%%D\pythonw.exe"
    )
)

if defined PYEXE (
    "%PYEXE%" --version >nul 2>nul
    if errorlevel 1 set "PYEXE="
)

if not defined PYEXE (
    echo Could not find a working Python install. Please run Install.bat first.
    pause
    exit /b 1
)

start "" "%PYEXE%" main.py
