@echo off
setlocal enabledelayedexpansion
set "CODE_DIR=%~dp0..\..\STS Scanner Data\src_rams"
cd /d "%CODE_DIR%"

echo ============================================================
echo  Building STS Rams.exe
echo ============================================================
echo This packages the app into a single .exe with the STS Rams
echo icon, so it can be pinned to your taskbar like a normal app
echo (the same way Discord or any other program works).
echo.
echo This only needs to be done once - after this, just pin the
echo .exe it creates and use that from now on.
echo ============================================================
echo.
pause

set "PYEXE="
where python >nul 2>nul
if %errorlevel% == 0 (
    for /f "delims=" %%P in ('where python') do (
        echo %%P | findstr /i "WindowsApps" >nul
        if errorlevel 1 (
            if not defined PYEXE set "PYEXE=%%P"
        )
    )
)
if not defined PYEXE (
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
        if exist "%%D\python.exe" set "PYEXE=%%D\python.exe"
    )
)
if defined PYEXE (
    "%PYEXE%" --version >nul 2>nul
    if errorlevel 1 set "PYEXE="
)
if not defined PYEXE (
    echo Could not find a working Python install. Please run Install.bat first.
    pause
    exit /b 1
)

echo Checking for PyInstaller...
"%PYEXE%" -m PyInstaller --version >nul 2>nul
if not %errorlevel% == 0 (
    echo Installing PyInstaller...
    "%PYEXE%" -m pip install pyinstaller --quiet --user
)

echo.
echo Building - this can take a minute or two...
"%PYEXE%" -m PyInstaller --noconfirm --onefile --windowed ^
    --name "STS Rams" ^
    --icon "assets\logo.ico" ^
    --add-data "templates;templates" ^
    --add-data "static;static" ^
    --add-data "assets;assets" ^
    main.py

if not exist "dist\STS Rams.exe" (
    echo.
    echo ERROR: Build did not produce an .exe. Scroll up for the error
    echo from PyInstaller above.
    pause
    exit /b 1
)

echo.
echo Moving the finished app back to the launcher folder...
copy /Y "dist\STS Rams.exe" "%~dp0STS Rams.exe" >nul

echo Cleaning up build files...
rmdir /s /q build >nul 2>nul
rmdir /s /q dist >nul 2>nul
del "STS Rams.spec" >nul 2>nul

echo.
echo ============================================================
echo  Done!
echo ============================================================
echo "STS Rams.exe" is now in this folder:
echo   %~dp0
echo.
echo Right-click it and choose "Pin to taskbar" to use it like any
echo other app - it will show the STS Rams icon.
echo ============================================================
pause
exit /b 0
