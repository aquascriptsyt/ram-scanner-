# STS Rams

A desktop app for logging RAM sticks by barcode. Works with a USB
barcode scanner (or manual typing), auto-detects the brand from the
scanned code, and logs everything straight into an Excel sheet - no
phone, no internet tunnel, no browser tab, no login codes.

## First-time setup

1. Run `Install.bat` (one level up from this folder) once - it sets
   up everything needed and creates the three folders this app uses:
   "STS Scanner Apps" (this folder lives in here), "STS Scanner Data"
   (the app's program files and settings), and "STS Scanner Sheets"
   (every Excel file you log).

## Everyday use

Double-click **Start STS Rams.bat**. That's it.

- First time on this computer: enter your name.
- Every time after: it remembers you and goes straight in.

Each time you start a new session, a brand new Excel sheet is created
with your name on it. You'll be asked what type of RAM you're logging
before you can scan anything - this gets saved at the top of the
sheet, and you can change it any time mid-session from the "Currently
Logging" card if you switch between RAM generations.

Then just scan. The app figures out the brand, capacity, speed, and
type on its own where it can. If a barcode can't be fully identified,
a red prompt walks you through filling in what's missing before it
lets you continue.

RAM sticks are counted in packages of 10, counting down from Card 10
to Card 1, and automatically roll over to the next package once a
package fills up. Tap **Save Package** to close one out early if
needed.

Sheets are split into sections by RAM generation (DDR, DDR2, DDR3,
DDR4, DDR5), each with a running total, plus a grand total at the
bottom - updated live as you scan.

Everything saves the moment you scan, and again the moment you close
the app - nothing is lost if you just shut the window.

## Pinning to your taskbar

By default this runs as a Python script via the `.bat` file, which
won't show a custom icon on your taskbar. To get a real pinnable app
(like Discord or any other program):

1. Double-click **Build App.bat** in this folder (one-time, takes a
   minute or two)
2. Once it finishes, you'll have an **STS Rams.exe** in this same
   folder
3. Right-click that .exe and choose **Pin to taskbar**

From then on, use the pinned icon instead of the `.bat` file.

## Excel Editor tab

- **Create New Sheet** - start a brand new sheet with any name you like
- **Continue this sheet** - pick up exactly where an old sheet left off
- **Delete** (the × next to a sheet) - permanently deletes it. This
  asks for the manager password and cannot be undone.

## Where your data lives

- Program files: `STS Scanner Data/src_rams`
- Settings, current session: `STS Scanner Data`
- Every Excel sheet: `STS Scanner Sheets`

This folder (`STS Scanner Apps/STS_Rams`) only ever contains the
launcher, the build script, and (after building) the .exe - nothing
else clutters it.
